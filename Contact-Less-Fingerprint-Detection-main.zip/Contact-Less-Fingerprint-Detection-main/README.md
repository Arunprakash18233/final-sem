# Contact-Less-Fingerprint-Detection-And-Recognition
A Open CV based fingerprint acquisition and extraction project in which we extract fingerprint from a cell phone camera image through image processing and then match the extracted and processed fingerprint with our database.
## Fingerprint Extraction
First, we have to convert the image so that our model can read it and extract the fingerprint patterns from it. And to know how go through 'fingerprint_extraction.ipynb' file.
